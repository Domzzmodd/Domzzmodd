global.owner = ["1234567890"];

global.namebot = "RxhL OfficiaL";
global.packname = "RxhL";
global.author = "OfficiaL";
